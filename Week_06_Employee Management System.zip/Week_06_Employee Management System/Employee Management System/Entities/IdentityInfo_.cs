﻿namespace EmployeeManagementSystem.DTO
{
    public class IdentityInfo_
    {
        public string PAN { get; set; }
        public string Aadhar { get; set; }
        public string Nationality { get; set; }
        public string PassportNumber { get; set; }
        public string PFNumber { get; set; }
    }
}
